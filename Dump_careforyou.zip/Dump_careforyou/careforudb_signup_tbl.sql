CREATE DATABASE  IF NOT EXISTS `careforudb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `careforudb`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: careforudb
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `signup_tbl`
--

DROP TABLE IF EXISTS `signup_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `signup_tbl` (
  `iSignupId` int NOT NULL AUTO_INCREMENT,
  `vUserName` varchar(30) NOT NULL,
  `vAddress` varchar(100) NOT NULL,
  `vEmail` varchar(30) NOT NULL,
  `vMobile` varchar(12) NOT NULL,
  `vGender` varchar(8) NOT NULL,
  `vPassword` varchar(15) NOT NULL,
  `vImage` varchar(45) DEFAULT NULL,
  `eStatus` enum('A','I') NOT NULL,
  PRIMARY KEY (`iSignupId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signup_tbl`
--

LOCK TABLES `signup_tbl` WRITE;
/*!40000 ALTER TABLE `signup_tbl` DISABLE KEYS */;
INSERT INTO `signup_tbl` VALUES (1,'meha','A/202 Divine Flats amraiwadi Ahmedabad','mehavora13@gmail.com','9111876543','female','13@MehaVora','u1.png','A'),(2,'Riya','2-Viswakarma Park Jivraj park ahmedabad','riya12@gmail.com','7823444612','female','riya@13P12','u1.png','A'),(3,'Niyan','51/Shreedhar society odhav ahmedabad','pateln@gmail.com','8966745123','male','12&NiyanP','u1.png','A'),(4,'Rutu','B/3,Ankleshwaria Block','chudasamarutu98@gmail.com','9806789543','female','123@Qwer','New Doc 2017-11-14_3.jpg','A'),(5,'Sweta','12/Paradise flat Satellite','spatel@gmail.com','8909787896','female','hutf6#hhj','u1.png','A'),(6,'Mukesh','101-Ganesh Park Delhi darwaja','12mpatel@gmail.com','7854906789','male','Mukesh@3455','u1.png','A');
/*!40000 ALTER TABLE `signup_tbl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-30 17:34:43
