CREATE DATABASE  IF NOT EXISTS `careforudb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `careforudb`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: careforudb
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctorinfo_tbl`
--

DROP TABLE IF EXISTS `doctorinfo_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctorinfo_tbl` (
  `iDoctorId` int NOT NULL AUTO_INCREMENT,
  `vFirstName` varchar(20) NOT NULL,
  `vLastName` varchar(20) NOT NULL,
  `vGender` varchar(6) NOT NULL,
  `vClinicAdd` varchar(85) NOT NULL,
  `vMobile` varchar(10) NOT NULL,
  `vPassword` varchar(15) NOT NULL,
  `vEmail` varchar(40) NOT NULL,
  `iFees` int NOT NULL DEFAULT '200',
  `vFileName` varchar(45) NOT NULL,
  `dBirthdate` date NOT NULL,
  `vLicense` varchar(45) NOT NULL,
  `vDegree` int NOT NULL,
  `iExperience` float NOT NULL,
  `iWorkType` int NOT NULL,
  `eStatus` enum('A','I') NOT NULL,
  PRIMARY KEY (`iDoctorId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctorinfo_tbl`
--

LOCK TABLES `doctorinfo_tbl` WRITE;
/*!40000 ALTER TABLE `doctorinfo_tbl` DISABLE KEYS */;
INSERT INTO `doctorinfo_tbl` VALUES (1,'Priti','Khanna','female','Nirnay Hospital,Second floor near Ambawadi Ahmedabad','9013390456','12@Priti12','priti12@gmail.com',400,'d6.jpg','1990-08-18','c1.png',6,4,3,'A'),(2,'Ritesh','Maliwal','male','Block2,Super mall second floor,Vejalpur','7658230934','12@Maliwal','maliwalr1@gmail.com',300,'d1.jpg','1995-06-15','physi.jpg',2,3,1,'A'),(3,'dhwami','shah','female','B/2 Denay Complex Bodakdev Ahmedabad','9090906789','123@Abcgte','dhwamish@gmail.com',200,'d3.jpg','1985-12-25','c1.png',1,7,3,'A'),(4,'Himani','patel','female','A/5 Shreedhar Complex Vastral Ahmedabad','7342610967','25@Himavor','himani@gmail.com',400,'d5.jpg','1997-03-20','c1.png',10,1,1,'A'),(5,'Shilpa','Bhatt','female','201,Gwalliya Complex Odhav Ahmedabad','9104340408','jain@23qwA','sjain4564@gmail.com',500,'d2.jpg','1980-04-23','c1.png',3,8,3,'A'),(6,'Kapil','Mali','male','KD Clinic, Shahpur ahmedabad','8967458800','mali@123A','kapilm12@gmail.com',150,'d4.jpg','1992-06-16','c1.png',11,5,3,'A'),(7,'Maulik','Shah','male','Alex complex, third floor vejalpur','7898985678','mauliK1@qw','maulik12@gmail.com',300,'d1.jpg','1987-02-02','c1.png',8,9,3,'A'),(8,'Manek','Das','male','C/3 Seema clinic near ADC bank Sarangpur','9420907893','Manik@12','manik@gmail.com',200,'d3.jpg','1998-01-03','c1.png',7,4,1,'A');
/*!40000 ALTER TABLE `doctorinfo_tbl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-30 17:34:41
